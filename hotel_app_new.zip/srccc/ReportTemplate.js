import React from 'react'

export default function ReportTemplate() {
  return (
    <div>
        <h1>Report Template</h1>
    </div>
  )
}
